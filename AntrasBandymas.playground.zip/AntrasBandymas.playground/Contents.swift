import UIKit

var greeting = "Hello, playground"
print ( greeting)

